// generated stub by JobQueue
